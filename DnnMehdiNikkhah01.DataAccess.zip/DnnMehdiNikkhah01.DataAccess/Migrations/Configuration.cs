namespace DnnMehdiNikkhah01.DataAccess.Migrations
{
    using EntityModel.Model;
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;

    public sealed class Configuration : DbMigrationsConfiguration<DnnMehdiNikkhah01.DataAccess.PersonContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(DnnMehdiNikkhah01.DataAccess.PersonContext context)
        {
            GetPersons().ForEach(p => context.Persons.Add(p));
            context.SaveChanges();
        }
        private static List<Person> GetPersons()
        {


            var persons = new List<Person> {
                new Person
                {

                    UserName = "George",
                    Name="George",
                    LastName="Doe",
                    Email="george.deo@email.com",
                    JoinedDate=DateTime.Now,
                    picture=null

               },
                 new Person
                {

                    UserName = "ash",
                    Name="ash",
                    LastName="prasad",
                    Email="ash.prasad@email.com",
                    JoinedDate=DateTime.Now,
                    picture=null

               },
                  new Person
                {

                    UserName = "com3773",
                    Name="Content Manager",
                    LastName="3773",
                    Email="com3773@test.com",
                    JoinedDate=DateTime.Now,
                    picture=null

               },
                   new Person
                {

                    UserName = "admin3773",
                    Name="Administrator",
                    LastName="3773",
                    Email="admin3773@change.com",
                    JoinedDate=DateTime.Now,
                    picture=null

               }
            };

            return persons;
        }
    }
}
