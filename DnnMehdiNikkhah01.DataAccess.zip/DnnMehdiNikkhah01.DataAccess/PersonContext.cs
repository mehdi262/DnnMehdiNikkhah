﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using DnnMehdiNikkhah01.EntityModel.Model;

namespace DnnMehdiNikkhah01.DataAccess
{
    public class PersonContext: DbContext
    {
        public PersonContext()
            :base("name=DnnMehdiNikkhah")
        {
            
        }
        public DbSet<Person> Persons { get; set; }
    }
}
