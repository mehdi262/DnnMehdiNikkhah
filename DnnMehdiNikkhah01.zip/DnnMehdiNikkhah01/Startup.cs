﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(DnnMehdiNikkhah01.Startup))]
namespace DnnMehdiNikkhah01
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
