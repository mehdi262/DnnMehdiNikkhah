using System.Web.Mvc;
using System.Web.Http;
using Microsoft.Practices.Unity;
using Unity.Mvc3;
using DnnMehdiNikkhah01.Controllers;
using DnnMehdiNikkhah01.DataAccess;
using DnnMehdiNikkhah01.Controllers.api;

namespace DnnMehdiNikkhah01
{
    public static class Bootstrapper
    {
        public static void Initialise()
        {
            var container = BuildUnityContainer();
            DependencyResolver.SetResolver(new UnityDependencyResolver(container));
        }

        private static IUnityContainer BuildUnityContainer()
        {
            var container = new UnityContainer();
            container.RegisterType<IPersonRepository, PersonRepository>(new HierarchicalLifetimeManager());
            container.RegisterType<IController, PersonController>("Person");
            return container;            
        }
    }
}